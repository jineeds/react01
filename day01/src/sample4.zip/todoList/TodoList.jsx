import './TodoList.scss';

const TodoList = () => {
  return <div className="TodoList"></div>;
};

export default TodoList;
