import './TodoInput.scss';

const TodoInput = () => {
  return <div className="TodoInput"></div>;
};

export default TodoInput;
